import { View, Text } from 'react-native';

export default function ContactsScreen() {
  return (
    <View>
      <Text>Dashboard</Text>
    </View>
  );
}

