# Native Manager Suite

Proyecto desarrollado en React Native con Expo.

Aplicación Todo-en-Uno que demuestra el uso de:
- Cámara (QR Scanner)
- Contactos
- Notificaciones
- Estado global y persistencia
